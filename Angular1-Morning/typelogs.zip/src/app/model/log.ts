export interface logItemDetails {
  text: string;
  date: any;
}
